package com.wipro.eb.exception;

public class InvalidConnectionException extends Exception{

	@Override
	public String toString() {
		//write code here
		return "Invalid ConnectionType";
	}

}
