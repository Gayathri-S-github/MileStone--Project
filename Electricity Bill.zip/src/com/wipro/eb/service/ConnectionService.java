package com.wipro.eb.service;


import com.wipro.eb.entity.Commercial;
import com.wipro.eb.entity.Connection;
import com.wipro.eb.entity.Domestic;
import com.wipro.eb.exception.InvalidConnectionException;
import com.wipro.eb.exception.InvalidReadingException;

public class ConnectionService {

	public boolean validate(int currentReading, int previousReading, String type)
			throws InvalidReadingException, InvalidConnectionException {
		//write code here
		if(currentReading<previousReading || currentReading<0 || previousReading<0 )
			throw new InvalidReadingException();
		else if(type.equals("Domestic") || type.equals("Commercial"))
			return true;
		else
			throw new InvalidConnectionException();
		//return true;
	}

	public float calculateBillAmt(int currentReading, int previousReading,	String type)
	{
		float a=0;
		try {
			this.validate(currentReading, previousReading, type);
			if(type.equals("Domestic"))
			{
				float aa[] = {2.3f,4.2f,5.5f};
				Connection c = new Domestic(currentReading, previousReading, aa) ;
				a=c.computeBill();
			}
			else 
			{
				float aa[] = {5.2f,6.8f,8.3f};
				Connection c = new Commercial(currentReading, previousReading, aa);
			a=	c.computeBill();
			}
		} catch (InvalidReadingException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return -1;
		} catch (InvalidConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -2;
		}
		//write code here
		return a;
	}
	
	public String generateBill(int currentReading, int previousReading,String type)
	{
		//write code here
		float a=0;
		float read=this.calculateBillAmt(currentReading, previousReading, type);
		if(this.calculateBillAmt(currentReading, previousReading, type)==-1)
			return "Incorrect Reading";
		else if(this.calculateBillAmt(currentReading, previousReading, type)==-2)
			return "Invalid ConnectionType";
		if(read>=10000)
		a= (float) (read*0.09);
	else if (read>=5000)
		a= (float) (read*0.06);
	else
		a= (float) (read*0.02);
		a=read+a;
		return "Amount to be paid:"+a;
	}

	
}
