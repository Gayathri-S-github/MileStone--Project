package com.wipro.flight.service;

import java.util.List;

import com.wipro.flight.bean.Flight;
import com.wipro.flight.dao.FlightDAO;


public class FlightService  {

	FlightDAO ff=new FlightDAO();
	public String createFlight(Flight flight) {
	 String result="";
		//String id=ff.getComputedId(flight.getFlightName(),"FlightID_Seq");
	
		if(flight==null)
		{
			return "FAIL";
		}
		else if(ff.getComputedId(flight.getFlightName(),"FlightID_Seq").equals("INVALID_INPUT"))
		{
			return "INVALID_INPUT";
		}
		else
		{
			flight.setFlightID(ff.getComputedId(flight.getFlightName(),"FlightID_Seq"));
			
			result=ff.addFlight(flight);
			if(result.equals("SUCCESS"))
			{
				return "SUCCESS";
			}
			else
			{
				return "INVALID_INPUT";
			}
		}
		
		
	
	}

}
