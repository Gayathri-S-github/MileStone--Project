package com.wipro.flight.util;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil {
	
	public static Connection getDBConnection()
	{
		Connection con=null;
		//write code here
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B20191820191820","B20191820191820");
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
}
}
