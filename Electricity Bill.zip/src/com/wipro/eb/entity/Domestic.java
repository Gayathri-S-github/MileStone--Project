package com.wipro.eb.entity;

public class Domestic extends Connection {

	public Domestic(int currentReading, int previousReading,float slabs[]) {
		super(currentReading, previousReading,slabs);

	}

	@Override
	public float computeBill() {
		//write code here
		float read = 0;
		int num=currentReading-previousReading;
		int i=0;
		for (float a:slabs)
		{
			i++;
			if(i==3)
			{
				read+=a*num;
				num=0;
			}
			if(num>=50)
			{
				read+=a*50.0f;
			}
			else {
				read+=a*num;
				num=0;
			}
			if(num==0)
				break;
			
		}
		return read;
		//return 0;
	}

}
